import pandas as pd
import os

# Diretório onde estão os ficheiros .xlsx
input_dir = "./xlsx"
output_dir = "./csv"

os.makedirs(output_dir, exist_ok=True)

for filename in os.listdir(input_dir):
    if filename.endswith(".xlsx"):
        file_path = os.path.join(input_dir, filename)
        xls = pd.ExcelFile(file_path)
        for sheet_name in xls.sheet_names:
            df_raw = xls.parse(sheet_name, header=None)

            if df_raw.shape[0] < 3:
                print(f"Folha muito curta: {sheet_name} em {filename}")
                continue

            # Primeira linha → título da folha (comentário no CSV)
            titulo_folha = str(df_raw.iloc[0, 0]).strip()

            # Segunda linha → nomes das colunas, limpos de quebras de linha
            colunas = [
                str(c).replace('\n', ' ').strip() if pd.notna(c) else ''
                for c in df_raw.iloc[1]
            ]

            # Dados reais = da terceira até à penúltima linha
            df = df_raw.iloc[2:-1].copy()
            df.columns = colunas

            # Nome do ficheiro baseado no nome da folha
            safe_sheet_name = "".join(c if c.isalnum() or c in " _-" else "_" for c in sheet_name)
            csv_filename = f"{safe_sheet_name}.csv"
            csv_path = os.path.join(output_dir, csv_filename)

            # Escrever o CSV com o título como primeira linha (comentário)
            with open(csv_path, mode='w', encoding='utf-8', newline='') as f:
                f.write(f"# {titulo_folha}\n")
                df.to_csv(f, index=False)

            print(f"Exportado: {csv_path}")